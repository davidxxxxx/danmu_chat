﻿# -*- coding:utf-8 -*-
import socket
import time
import threading
import queue
import re


class GetDanMuSocket():
    # Configure socket's IP and port
    def __init__(self):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # douyu website 
        # openbarrage.douyutv.com no longer use
        # 119.96.201.28  
        # user danmuproxy.douyu.com instead
        self.host = socket.gethostbyname("danmuproxy.douyu.com")
        self.port = 8601
        self.dmDict = {}
        self.dmqu = queue.Queue(maxsize=10000)
        self.client.connect((self.host, self.port))

    # Regular expressions for user nickname and danmu information
    def setup_regex(self):
        self.danmu = re.compile(
            'type@=chatmsg.*?/rid@=(.*?)/(?:ct@=(.*?)/)?uid@=(.*?)/nn@=(.*?)/'
            'txt@=(.*?)/cid@=(.*?)/.*?level@=(.*?)/sahf@=0/(?:nl@=(.*?)/)?(?:col@=(.*?)/)?.*?bnn@=(.*?)/bl@=(.*?)/brid@=(.*?)/'
        )
        # Authority
        self.authority = re.compile('type@=chatmsg.*?/rg@=(.*?)/')

    def sendmsg(self, msgstr):
        # Protocol header according to Douyu protocol
        msg = msgstr.encode('utf-8')
        data_length = len(msg) + 8
        code = 689
        msgHead = int.to_bytes(data_length, 4, 'little') \
                  + int.to_bytes(data_length, 4, 'little') + int.to_bytes(code, 4, 'little')
        self.client.send(msgHead)
        sent = 0
        while sent < len(msg):
            tn = self.client.send(msg[sent:])
            sent = sent + tn

    def keeplive(self):
        # Send heartbeat packets to the server to maintain a long connection
        def sendhf():
            while True:
                msg = 'type@=mrkl/\0'
                self.sendmsg(msg)
                time.sleep(30)

        t = threading.Thread(target=sendhf)
        t.start()

    def start(self, roomid):
        self.setup_regex()

        msg = 'type@=loginreq/roomid@={}/\0'.format(roomid)
        # Log in
        self.sendmsg(msg)
        print(msg)
        msg_more = 'type@=joingroup/rid@={}/gid@=-9999/\0'.format(roomid)
        # Join group
        self.sendmsg(msg_more)
        print(msg_more)

        self.keeplive()

        while True:
            data = self.client.recv(1024)
            danmu_more = self.danmu.findall(data.decode(encoding='utf-8', errors='ignore'))

            if not data:
                break
            else:
                try:
                    for i in danmu_more:
                        i = list(i)
                        print(i)
                except:
                    continue


if __name__ == '__main__':
    room_id = input("Enter the room id: ")
    danmu_socket = GetDanMuSocket()
    danmu_socket.start(room_id)
